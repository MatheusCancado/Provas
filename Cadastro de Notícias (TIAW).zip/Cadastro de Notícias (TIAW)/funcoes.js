$(function(){
	function Adicionar(){
		$("#tblCadastro tbody").append(
			"<tr>"+
			"<td><input type='text'/></td>"+
			"<td><input type='text'/></td>"+
			"<td><input type='text'/></td>"+
			"<td><input type='text'/></td>"+
			"<td><img src='images/disk.png' class='btnSalvar'><img src='images/delete.png' class='btnExcluir'/></td>"+
			"</tr>");

		$(".btnSalvar").bind("click", Salvar);     
		$(".btnExcluir").bind("click", Excluir);
	};

	function Salvar(){
		var par = $(this).parent().parent(); //tr
		var tdTitulo = par.children("td:nth-child(1)");
		var tdVeiculo = par.children("td:nth-child(2)");
		var tdAutor = par.children("td:nth-child(3)");
		var tdLink = par.children("td:nth-child(4)");
		var tdBotoes = par.children("td:nth-child(5)");

		tdTitulo.html(tdTitulo.children("input[type=text]").val());
		tdVeiculo.html(tdVeiculo.children("input[type=text]").val());
		tdAutor.html(tdAutor.children("input[type=text]").val());
		tdLink.html(tdLink.children("input[type=text]").val());
		tdBotoes.html("<img src='images/delete.png'class='btnExcluir'/><img src='images/pencil.png' class='btnEditar'/>");

		$(".btnEditar").bind("click", Editar);
		$(".btnExcluir").bind("click", Excluir);
	};

	function Editar(){
		var par = $(this).parent().parent(); //tr
		var tdTitulo = par.children("td:nth-child(1)");
		var tdVeiculo = par.children("td:nth-child(2)");
		var tdAutor = par.children("td:nth-child(3)");
		var tdLink = par.children("td:nth-child(4)");
		var tdBotoes = par.children("td:nth-child(5)");

		tdTitulo.html("<input type='text' id='txtTitulo' value='"+tdTitulo.html()+"'/>");
		tdVeiculo.html("<input type='text'id='txtVeiculo' value='"+tdVeiculo.html()+"'/>");
		tdAutor.html("<input type='text' id='txtAutor' value='"+tdAutor.html()+"'/>");
		tdLink.html("<input type='text' id='txtLink' value='"+tdLink.html()+"'/>");
		tdBotoes.html("<img src='images/disk.png' class='btnSalvar'/>");

		$(".btnSalvar").bind("click", Salvar);
		$(".btnEditar").bind("click", Editar);
		$(".btnExcluir").bind("click", Excluir);
	};

	function Excluir(){
	    var par = $(this).parent().parent(); //tr
	    par.remove();
	};

	$(".btnEditar").bind("click", Editar);
	$(".btnExcluir").bind("click", Excluir);
	$("#btnAdicionar").bind("click", Adicionar); 
});
