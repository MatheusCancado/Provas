#include <stdio.h>
#include <string.h>
#include <locale.h>
#include <stdbool.h>
#include <stdlib.h>
//Nome : Matheus Miranda Can�ado
//30/11/2020
/*----------------------------------------------------------------------------
------------------------------------------------------------------------------
------------------------------------------------------------------------------
---------------------------------------------------*/
void menu();
void Ex_01();
void Ex_02();
void Ex_03();
void Ex_04();
void Ex_05();
int main()
{
setlocale(LC_ALL, "portuguese");
menu();
return 0;
}
void menu()
{
int op;
do
{
printf("MENU: \n01. Exercicio 01 \n02. Exercicio 02 \n03. Exercicio 03 \n04. Exercicio 04 \n05. Exercicio 05 \n0. Sair \n Escolha uma opcao:");
scanf("%d", &op);
switch (op)
{
case 1:
    Ex_01();
    break;
case 2:
    Ex_02();
    break;
case 3:
    Ex_03();
    break;
case 4:
    Ex_04();
    break;
case 5:
    Ex_05();
    break;
default:
    printf("Op��o inv�lida! \n");
    break;
}
} while (op != 0);
}
/*----------------------------------------------------------------------------
------------------------------------------------------------------------------
------------------------------------------------------------------------------
---------------------------------------------------
/*a) - gravar em um arquivo os 64 primeiros valores da s�rie: 1 1 2 3 5 8 13
21 34 . . .*/
void Ex_01()
{
FILE *arquivoFib;
double primeiro, segundo, terceiro;
primeiro = 1;
segundo = 0;
terceiro = 1;
FILE *fopen(const char *arquivoFib, const char *w);
printf("\n---------------------------------------------------------------------------------------------------------------------\n");
printf("\na) - gravar em um arquivo os 64 primeiros valores da s�rie de fibonacci: 1 1 2 3 5 8 13 21 34 . . .\n");
printf("\n---------------------------------------------------------------------------------------------------------------------\n");
if ((arquivoFib = fopen("arquivoFib.txt", "w")) == NULL) // modo de escrita ativo
{
printf("Erro de abertura! \n");
}
else
{
for (int i = 0; i < 64; ++i)
{
fprintf(arquivoFib, "%.lf \n", primeiro);
primeiro = segundo + terceiro;
segundo = terceiro;
terceiro = primeiro;
printf("%.lf \n", primeiro);
}
fclose(arquivoFib);
printf("\n----------------------------------------------------------------------------------------------------------------------\n");
}
fflush(stdin);
system("pause");
system("Cls");
}
/*----------------------------------------------------------------------------
------------------------------------------------------------------------------
------------------------------------------------------------------------------
---------------------------------------------------*/
/*b) - ler o arquivo letra a e armazenar os dados em uma matriz 8 x 8 imprima
essa matriz na tela*/
void Ex_02()
{
float Matriz[8][8];
FILE *arquivoFib;
printf("\n---------------------------------------------------------------------------------------------------------------------\n");
printf("\nb) - ler o arquivo letra a e armazenar os dados em uma matriz 8 x 8 imprima essa matriz na tela\n");
printf("\n----------------------------------------------------------------------------------------------------------------------\n");
if ((arquivoFib = fopen("arquivoFib.txt", "r")) == NULL)
{
printf("Erro de abertura! \n");
}
else
{
for (int j = 0; j < 8; ++j)
{
for (int i = 0; i < 8; ++i)
{
fscanf(arquivoFib, "%f", &Matriz[j][i]);
}
}
for (int j = 0; j < 8; ++j)
{
for (int i = 0; i < 8; ++i)
{
printf("[%.lf] ", Matriz[j][i]);
}
printf("\n");
}
fclose(arquivoFib);
printf("\n----------------------------------------------------------------------------------------------------------------------\n");
}
fflush(stdin);
system("pause");
system("Cls");
}
/*----------------------------------------------------------------------------
------------------------------------------------------------------------------
------------------------------------------------------------------------------
---------------------------------------------------*/
/*c) - ler o arquivo letra a e armazenar os dados em uma matriz 8 x 8 armazene
essa matriz em um arquivo.*/
void Ex_03()
{
float Matriz[8][8];
FILE *MatrizFib;
FILE *arquivoFib;
printf("\n----------------------------------------------------------------------------------------------------------------------\n");
printf("\nc) - ler o arquivo letra a e armazenar os dados em uma matriz 8 x 8 armazene essa matriz em um arquivo\n");
printf("\n----------------------------------------------------------------------------------------------------------------------\n");
if ((arquivoFib = fopen("arquivoFib.txt", "r")) == NULL)
{
printf("Erro de abertura! \n");
}
else
{
for (int j = 0; j < 8; ++j)
{
for (int i = 0; i < 8; ++i)
{
fscanf(arquivoFib, "%f", &Matriz[j][i]);
}
}
for (int j = 0; j < 8; ++j)
{
for (int i = 0; i < 8; ++i)
{
printf("[%.lf] ", Matriz[j][i]);
}
printf("\n");
}
fclose(arquivoFib);
}
if ((MatrizFib = fopen("MatrizFIb.txt", "w")) == NULL)
{
printf("Erro de abertura! \n");
}
else
{
for (int j = 0; j < 8; ++j)
{
for (int i = 0; i < 8; ++i)
{
fprintf(MatrizFib, "[%.lf] ", Matriz[j][i]);
}
fprintf(MatrizFib, "\n");
}
fclose(MatrizFib);
}
printf("\n----------------------------------------------------------------------------------------------------------------------\n");
fflush(stdin);
system("pause");
system("Cls");
}
/*----------------------------------------------------------------------------
------------------------------------------------------------------------------
------------------------------------------------------------------------------
---------------------------------------------------*/
/*d) - ler o arquivo letra a e armazenar os valores pares em um arquivo e os
impares em outro arquivo*/
void Ex_04()
{
float Matriz[8][8];
FILE *Impar;
FILE *Par;
FILE *arquivoFib;
printf("\n---------------------------------------------------------------------------------------------------------------------\n");
printf("\nd) - ler o arquivo letra a e armazenar os valores pares em um arquivo e os impares em outro arquivo\n");
printf("\n----------------------------------------------------------------------------------------------------------------------\n");
printf("Aquivo criado com sucesso !!!!!");
printf("\n----------------------------------------------------------------------------------------------------------------------\n");
if ((arquivoFib = fopen("arquivoFib.txt", "r")) == NULL)
{
printf("Erro de abertura! \n");
}
else
{
for (int j = 0; j < 8; ++j)
{
for (int i = 0; i < 8; ++i)
{
fscanf(arquivoFib, "%f", &Matriz[j][i]);
}
printf("\n");
}
fclose(arquivoFib);
}
if ((Par = fopen("Par.txt", "w")) == NULL)
{
printf("Erro de abertura! \n");
}
if ((Impar = fopen("Impar.txt", "w")) == NULL)
{
printf("Erro de abertura! \n");
}
else
{
for (int j = 0; j < 8; ++j)
{
for (int i = 0; i < 8; ++i)
{
if (fmod(Matriz[j][i], 2) != 0)
{
fprintf(Impar, "[%.lf] ", Matriz[j][i]);
}
else
{
fprintf(Par, "[%.lf] ", Matriz[j][i]);
}
}
fprintf(Impar, "\n");
fprintf(Par, "\n");
}
fclose(Impar);
fclose(Par);
}
fflush(stdin);
system("pause");
system("Cls");
}
/*----------------------------------------------------------------------------
------------------------------------------------------------------------------
------------------------------------------------------------------------------
---------------------------------------------------*/
/*e) - ler o arquivo letra a e armazenar em um vetor apenas os primos, imprima
esse vetor, e salve os dados
desse vetor em um arquivo.*/
int Primo(double Valor);
void Ex_05()
{
float Matriz[8][8];
int Prim[64];
FILE *Primos;
FILE *arquivoFib;
printf("\n---------------------------------------------------------------------------------------------------------------------\n");
printf("\ne) - ler o arquivo letra a e armazenar em um vetor apenas os primos, imprima esse vetor, e salve os dados desse vetor em um arquivo\n");
printf("\n----------------------------------------------------------------------------------------------------------------------\n");
if ((arquivoFib = fopen("arquivoFib.txt", "r")) == NULL)
{
printf("Erro de abertura! \n");
}
else
{
for (int j = 0; j < 8; ++j)
{
for (int i = 0; i < 8; ++i)
{
fscanf(arquivoFib, "%f", &Matriz[j][i]);
}
}
fclose(arquivoFib);
}
if ((Primos = fopen("Primos.txt", "w")) == NULL)
{
printf("Erro de abertura! \n");
}
else
{
for (int j = 0; j < 8; ++j)
{
for (int i = 0; i < 8; ++i)
{
if ((Primo(Matriz[j][i]) == 1))
{
fprintf(Primos, "[%.lf] ", Matriz[j][i]);
printf("[%.lf] ", Matriz[j][i]);
printf("\n");
}
}
}
}
printf("\n----------------------------------------------------------------------------------------------------------------------\n");
fflush(stdin);
system("pause");
system("Cls");
}
int Primo(double Valor)
{
double i;
for (i = 2; i <= (Valor / 2); ++i)
{
if (fmod(Valor, i) == 0)
{
return 0;
}
return 1;
}
}
/*----------------------------------------------------------------------------
------------------------------------------------------------------------------
------------------------------------------------------------------------------
---------------------------------------------------*/
